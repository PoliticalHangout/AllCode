# Verificinator
A discord bot made to handle verification for the Political Hangout Discord Server.
